const crypto = require("crypto");
const razorpay = require("../config/razorpay");
const UserDeposit = require("../models/UserDeposit");
const User = require("../models/usermodel");
const ReferralSetting = require("../models/ReferralSetting");

exports.createRazorpayOrder = async (req, res) => {
  try {
    const { amount } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ message: "Invalid amount" });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const order = await razorpay.orders.create({
      amount: amount * 100,
      currency: "INR",
      receipt: `rcpt_${Date.now()}`,
    });

    await UserDeposit.create({
      user: user._id,
      userUid: user.uid,
      mobile: user.mobile,
      amount,
      razorpayOrderId: order.id,
      status: "pending",
    });

    res.json({
      success: true,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      key: process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    console.error("Create Order Error:", err);
    res.status(500).json({ message: "Order creation failed" });
  }
};

/* ==================================
   VERIFY RAZORPAY PAYMENT (USER)
================================== */
exports.verifyRazorpayPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ message: "Missing payment details" });
    }

    /* ===== VERIFY SIGNATURE ===== */
    const body = razorpay_order_id + "|" + razorpay_payment_id;

    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    if (expectedSignature !== razorpay_signature) {
      return res.status(400).json({ message: "Payment verification failed" });
    }

    /* ===== ATOMIC DEPOSIT UPDATE ===== */
    const deposit = await UserDeposit.findOneAndUpdate(
      {
        razorpayOrderId: razorpay_order_id,
        status: { $ne: "approved" },
      },
      {
        razorpayPaymentId: razorpay_payment_id,
        razorpaySignature: razorpay_signature,
        status: "approved",
        approvedAt: new Date(),
      },
      { new: true }
    );

    if (!deposit) {
      return res.status(400).json({ message: "Deposit already processed" });
    }

    /* ===== CREDIT USER ===== */
    const user = await User.findById(deposit.user);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.credit += deposit.amount;
    await user.save();

    /* ===== REFERRAL COMMISSION ===== */
    if (user.inviteCode) {
      const referrer = await User.findOne({
        myInviteCode: user.inviteCode,
      });

      if (referrer) {
        const approvedCount = await UserDeposit.countDocuments({
          user: user._id,
          status: "approved",
        });

        const setting = await ReferralSetting.findOne({
          level: approvedCount,
        });

        if (setting && setting.percent > 0) {
          const commission =
            (deposit.amount * setting.percent) / 100;

          referrer.credit += commission;
          await referrer.save();
        }
      }
    }

    res.json({
      success: true,
      message: "Payment successful & credit added",
    });
  } catch (err) {
    console.error("Verify Payment Error:", err);
    res.status(500).json({ message: "Verification failed" });
  }
};

/* ======================
   MY DEPOSITS (USER)
====================== */
exports.getMyDeposits = async (req, res) => {
  try {
    const userId = req.user._id;

    const deposits = await UserDeposit.find({ user: userId })
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      deposits,
    });
  } catch (err) {
    console.error("Get My Deposits Error:", err);
    res.status(500).json({ message: "Failed to fetch deposits" });
  }
};


/* ======================
   ALL USER DEPOSITS (ADMIN)
====================== */
exports.getAllUserDeposits = async (req, res) => {
  try {
    const deposits = await UserDeposit.find()
      .populate("user", "uid mobile email")
      .sort({ createdAt: -1 });

    res.json({ success: true, deposits });
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch deposits" });
  }
};

/* ======================
   APPROVE / REJECT (ADMIN)
====================== */
exports.updateUserDepositStatus = async (req, res) => {
  try {
    const { status, remark } = req.body;

    if (!["approved", "rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" });
    }

    const deposit = await UserDeposit.findById(req.params.id);
    if (!deposit) {
      return res.status(404).json({ message: "Deposit not found" });
    }

    if (deposit.status !== "pending") {
      return res
        .status(400)
        .json({ message: "Deposit already processed" });
    }

    deposit.status = status;
    deposit.adminRemark = remark || null;
    deposit.approvedAt = status === "approved" ? new Date() : null;
    await deposit.save();

    /* ===== ON APPROVAL ===== */
    if (status === "approved") {
      const user = await User.findById(deposit.user);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Wallet balance add
      user.wallet.balance += deposit.amount;
      await user.save();

      /* ===== REFERRAL COMMISSION ===== */
      if (user.inviteCode) {
        const referrer = await User.findOne({
          myInviteCode: user.inviteCode,
        });

        if (referrer) {
          const approvedCount = await UserDeposit.countDocuments({
            user: user._id,
            status: "approved",
          });

          const setting = await ReferralSetting.findOne({
            level: approvedCount,
          });

          if (setting && setting.percent > 0) {
            const commission =
              (deposit.amount * setting.percent) / 100;

            referrer.wallet.balance += commission;
            await referrer.save();
          }
        }
      }
    }

    res.json({
      success: true,
      message: `Deposit ${status} successfully`,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Update failed" });
  }
};
