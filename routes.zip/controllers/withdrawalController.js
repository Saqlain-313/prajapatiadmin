const Withdrawal = require("../models/withdrawalModel");
const User = require("../models/usermodel");

/* ============================
   USER → REQUEST WITHDRAWAL
============================ */
exports.createWithdrawal = async (req, res) => {
  try {
    const userId = req.user._id;
    const { amount, method, upiId, bankDetails } = req.body;

    if (!amount || amount <= 0) {
      return res.status(400).json({ message: "Invalid amount" });
    }

    const user = await User.findById(userId);
    if (!user || user.credit < amount) {
      return res.status(400).json({ message: "Insufficient balance" });
    }

    const withdrawal = await Withdrawal.create({
      user: userId,
      amount,
      method,
      upiId,
      bankDetails,
    });

    // 🔒 lock balance until admin decision
    user.credit -= amount;
    await user.save();

    res.status(201).json({
      success: true,
      message: "Withdrawal request submitted",
      withdrawal,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Withdrawal failed" });
  }
};

/* ============================
   USER → MY WITHDRAWALS
============================ */
exports.getMyWithdrawals = async (req, res) => {
  try {
    const withdrawals = await Withdrawal.find({ user: req.user._id })
      .sort({ createdAt: -1 });

    res.json({ success: true, withdrawals });
  } catch (err) {
    res.status(500).json({ message: "Fetch failed" });
  }
};

/* ============================
   ADMIN → ALL WITHDRAWALS
============================ */
exports.getAllWithdrawals = async (req, res) => {
  try {
    const withdrawals = await Withdrawal.find()
      .populate("user", "mobile email uid")
      .sort({ createdAt: -1 });

    res.json({ success: true, withdrawals });
  } catch (err) {
    res.status(500).json({ message: "Fetch failed" });
  }
};

/* ============================
   ADMIN → APPROVE
============================ */
exports.approveWithdrawal = async (req, res) => {
  try {
    const { id } = req.params;

    const withdrawal = await Withdrawal.findById(id);
    if (!withdrawal || withdrawal.status !== "pending") {
      return res.status(400).json({ message: "Invalid request" });
    }

    withdrawal.status = "approved";
    withdrawal.processedAt = new Date();
    await withdrawal.save();

    res.json({
      success: true,
      message: "Withdrawal approved",
    });
  } catch (err) {
    res.status(500).json({ message: "Approval failed" });
  }
};

/* ============================
   ADMIN → REJECT
============================ */
exports.rejectWithdrawal = async (req, res) => {
  try {
    const { id } = req.params;
    const { remark } = req.body;

    const withdrawal = await Withdrawal.findById(id);
    if (!withdrawal || withdrawal.status !== "pending") {
      return res.status(400).json({ message: "Invalid request" });
    }

    // refund credit
    const user = await User.findById(withdrawal.user);
    user.credit += withdrawal.amount;
    await user.save();

    withdrawal.status = "rejected";
    withdrawal.adminRemark = remark || "Rejected by admin";
    withdrawal.processedAt = new Date();
    await withdrawal.save();

    res.json({
      success: true,
      message: "Withdrawal rejected & amount refunded",
    });
  } catch (err) {
    res.status(500).json({ message: "Rejection failed" });
  }
};
