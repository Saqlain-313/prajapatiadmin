import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

/* =========================
   AXIOS INSTANCE
========================= */
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:5000/api",
  withCredentials: true, // 🔥 if admin auth required
});

/* =========================
   ASYNC THUNKS
========================= */

/* GET IMAGES */
export const getImages = createAsyncThunk(
  "images/get",
  async (_, { rejectWithValue }) => {
    try {
      const { data } = await api.get("/images");
      return data;
    } catch (err) {
      return rejectWithValue("Failed to fetch images");
    }
  }
);

/* UPLOAD IMAGES (MULTIPLE) */
export const uploadImages = createAsyncThunk(
  "images/upload",
  async (files, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      files.forEach((file) => formData.append("images", file));

      const { data } = await api.post("/images/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      return data.images;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || "Image upload failed"
      );
    }
  }
);

/* UPDATE IMAGE BY INDEX */
export const updateImageByIndex = createAsyncThunk(
  "images/update",
  async ({ index, file }, { rejectWithValue }) => {
    try {
      const formData = new FormData();
      formData.append("image", file);

      const { data } = await api.put(`/images/update/${index}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      return { index, image: data.updatedImage };
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || "Image update failed"
      );
    }
  }
);

/* =========================
   SLICE
========================= */
const imageSlice = createSlice({
  name: "images",
  initialState: {
    images: [],
    total: 0,
    loading: false,
    error: null,
    success: false,
  },

  reducers: {
    clearImageState: (state) => {
      state.loading = false;
      state.error = null;
      state.success = false;
    },
  },

  extraReducers: (builder) => {
    builder

      /* GET IMAGES */
      .addCase(getImages.pending, (state) => {
        state.loading = true;
      })
      .addCase(getImages.fulfilled, (state, action) => {
        state.loading = false;
        state.images = action.payload.images;
        state.total = action.payload.total;
      })
      .addCase(getImages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      /* UPLOAD IMAGES */
      .addCase(uploadImages.pending, (state) => {
        state.loading = true;
      })
      .addCase(uploadImages.fulfilled, (state, action) => {
        state.loading = false;
        state.success = true;
        state.images = action.payload;
        state.total = action.payload.length;
      })
      .addCase(uploadImages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })

      /* UPDATE IMAGE BY INDEX */
      .addCase(updateImageByIndex.fulfilled, (state, action) => {
        const { index, image } = action.payload;
        if (state.images[index]) {
          state.images[index] = image;
        }
      });
  },
});

export const { clearImageState } = imageSlice.actions;
export default imageSlice.reducer;
