const axios = require("axios");
const AuthModel = require("../../models/usermodel");

// const apiUrl = "https://zapcore.live/api/test/launch-game/fun";
const apiUrl = "https://zapcore.live/api";
const key = "3aqSD5NzX8sKj2MG2CkNS6mqerzJywUW";

/**
 * CHECK BALANCE
 */
const checkBalance = async (req, res) => {
  try {
    const playerid = req.body.playerid;

    if (!playerid) {
      return res.status(400).json({
        message: "Undefined token",
        status: false,
      });
    }

    const response = await axios.post(`${apiUrl}/Userbalance`, {
      playerid,
      key,
    });

    if (response.data.status) {
      return res.status(200).json({
        message: "get balance successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * TRANSFER BALANCE
 */
const transferBalance = async (req, res) => {
  const id = req.user._id;

  console.log(req.user)


  try {
    const user = await AuthModel.findById(id);
    if (!user) {
      return res.status(400).json({
        message: "Undefined token",
        status: false,
      });
    }


    const responses = await axios.post(


      `${apiUrl}/Userbalance`,
      {
        playerid: isNaN(Number(user.mobile)) ? 0 : Number(user.mobile),
        key,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        }
      }
    );


    console.log(responses,"userr...")



    const credit = Number(responses.data.balance || 0);


    if (credit <= 0) {
      return res.status(400).json({
        message: "unable too share",
        status: false,
      });
    }

    await AuthModel.findByIdAndUpdate(
      id,
      {
        $inc: {  credit:credit },
      },
      { new: true }
    );

    const response = await axios.post(
      `${apiUrl}/Setbalance`,
      {
        playerid: isNaN(Number(user.mobile)) ? 0 : Number(user.mobile),
        key,
        opening_balance: credit,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        }
      }
    );


    if (response.data.status) {
      return res.status(200).json({
        message: "Transfer balance successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};


/**
 * LAUNCH GAME
 */
const launchGame = async (req, res) => {
  const id = req.user._id;
  let resdata = null;

  try {
    const { gameId } = req.body;

    if (!gameId) {
      return res.status(400).json({
        status: false,
        message: "gameId is required",
      });
    }

    const user = await AuthModel.findById(id);

    if (!user) {
      return res.status(200).json({
        status: false,
        message: "Invalid user",
      });
    }

    const response = await axios.post(
      "https://zapcore.live/api/test/launch-game/fun",
      {
        playerid: isNaN(Number(user.mobile)) ? 0 : Number(user.mobile),
        key,
        uid: gameId,
        opening_balance: user.credit,
      }
    );

    resdata = response.data;

    if (resdata?.status === true) {
      await AuthModel.findByIdAndUpdate(
        id,
        { credit: 0 },
        { new: true }
      );

      return res.status(200).json({
        status: true,
        message: "Game launched successfully",
        data: resdata,
      });
    }

    return res.status(500).json({
      status: false,
      message: "Game launch failed",
      error: resdata,
    });

  } catch (error) {
    if (error.response?.data) {
      resdata = error.response.data;
    }

    console.error("Launch game error:", error.message);

    return res.status(500).json({
      status: false,
      message: "Internal server error",
      error: error.message,
      data: resdata,
    });
  }
};


/**
 * GET GAME DETAILS
 */
const getgamedetails = async (req, res) => {
  try {
    const { page = 1, size = 1915 } = req.query;

    const response = await axios.get(
      `${apiUrl}/getgamedetails?page=${page}&size=${size}`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game list successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME PROVIDER
 */
const gameProvider = async (req, res) => {
  try {
    const response = await axios.get(
      `${apiUrl}/getgamedetails?provider_list=1`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game provider successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME TYPE
 */
const gameType = async (req, res) => {
  try {
    const response = await axios.get(
      `${apiUrl}/getgamedetails?gametype_list=1`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game type successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME LIST BY PROVIDER
 */
const gameListByProvider = async (req, res) => {
  try {
    const { provider = "spribe", page = 1, size = 10 } = req.query;

    const response = await axios.get(
      `${apiUrl}/getgamedetails?provider=${provider}&page=${page}&size=${size}`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game list successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME LIST BY GAME TYPE
 */
const gameListByGameType = async (req, res) => {
  try {
    const { game_type = "CasinoLive", page = 1, size = 20 } = req.query;

    const response = await axios.get(
      `${apiUrl}/getgamedetails?game_type=${game_type}&page=${page}&size=${size}`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game type successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME LIST BY GAME TYPE & PROVIDER
 */
const gameListByGameTypeAndProvider = async (req, res) => {
  try {
    const { provider, game_type, page, size } = req.query;

    const response = await axios.get(
      `${apiUrl}/getgamedetails?provider=${provider}&game_type=${game_type}&page=${page}&size=${size}`
    );

    if (response.data.status) {
      return res.status(200).json({
        message: "get game type successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * GAME HISTORY
 */
const gameHistory = async (req, res) => {
  try {
    const { page, size } = req.body;
    const playerid = req.params.id;

    const payload = {
      playerid,
      page,
      size,
      uid: "e333695bcff28acdbecc641ae6ee2b23",
      key,
    };

    const response = await axios.post(`${apiUrl}/history`, payload);

    if (response.data.status) {
      return res.status(200).json({
        message: "get game history successfully.",
        status: true,
        data: response.data,
      });
    }

    return res.status(500).json({
      message: "Internal server error",
      status: false,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Internal server error",
      status: false,
      error: error.message,
    });
  }
};

/**
 * EXPORTS (COMMONJS)
 */
module.exports = {
  checkBalance,
  transferBalance,
  launchGame,
  getgamedetails,
  gameProvider,
  gameType,
  gameListByProvider,
  gameListByGameType,
  gameListByGameTypeAndProvider,
  gameHistory,
};
