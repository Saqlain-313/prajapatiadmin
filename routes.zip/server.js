const express = require("express");
const cookieParser = require("cookie-parser");
const compression = require("compression");
const path = require("path");
const cors = require("cors")

require("colors");
require("dotenv").config();

const connectDB = require("./config/db");

const app = express();

/* ================= MIDDLEWARES ================= */
app.use(
  cors({
    origin: ["http://localhost:5173"],
    credentials: true,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(compression());

/* ================= ROUTES ================= */
app.get("/pay-test", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use("/api/user", require("./routes/userRoute"));
app.use("/api/notification", require("./routes/notificationRoute"));
app.use("/api/images", require("./routes/imageRoutes"));
app.use("/api/deposits", require("./routes/depositRoutes"));
app.use("/api/payment", require("./routes/paymentRoutes"));
app.use("/api/withdrawal", require("./routes/withdrawalRoute"));
app.use("/api/products", require("./routes/productRoutes"));
app.use("/api/referral", require("./routes/referralSettingRoutes"));
app.use("/api/game", require("./routes/allgameroute/allGameRoute"));
app.use("/api/user-deposit", require('./routes/userDepositRoutes'));

/* ================= DB CONNECT ================= */
connectDB();

/* ================= SERVER ================= */
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`.green.bold);
});