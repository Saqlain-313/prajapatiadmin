const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");

const userSchema = new mongoose.Schema(
  {
    /* ======================
       BASIC IDENTIFIERS
    ====================== */
    uid: {
      type: String,
      default: uuidv4,
      unique: true,
      index: true,
    },

    name: {
      type: String,
      trim: true,
      default: "",
    },

    mobile: {
      type: Number,
      unique: true,
      required: true,
    },

    email: {
      type: String,
      lowercase: true,
      trim: true,
      unique: true,
      sparse: true, // ✅ allows null emails
    },

    /* ======================
       AUTH
    ====================== */
    password: {
      type: String,
      required: true,
      select: false, // 🔐 never leak password
    },

    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
      index: true,
    },

    status: {
      type: String,
      enum: ["active", "blocked"],
      default: "active",
      index: true,
    },

    isDemo: {
      type: Boolean,
      default: false,
      index: true,
    },

    /* ======================
       WALLET / CREDIT
       (Zapcore sync safe)
    ====================== */
    credit: {
      type: Number,
      default: 0,
      min: 0,
    },

    totalWithdrawn: {
      type: Number,
      default: 0,
      min: 0,
    },

    /* ======================
       REFERRAL SYSTEM
    ====================== */
    inviteCode: {
      type: String, // code used at signup
      default: null,
      index: true,
    },

    myInviteCode: {
      type: String, // user's own referral code
      unique: true,
      index: true,
      default: () => uuidv4().slice(0, 8),
    },

    /* ======================
       FORGOT PASSWORD (OTP)
    ====================== */
    reset_otp: {
      type: String,
      default: null,
      select: false,
    },

    reset_otp_expiry: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true }
);

/* ======================
   PASSWORD HASHING
====================== */
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  this.password = await bcrypt.hash(this.password, 10);
});

/* ======================
   INSTANCE METHODS
====================== */

// 🔐 Compare password
userSchema.methods.comparePassword = function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

// ⏱ OTP expiry check
userSchema.methods.isOtpExpired = function () {
  return !this.reset_otp_expiry || this.reset_otp_expiry < Date.now();
};

/* ======================
   CREDIT METHODS (SAFE)
====================== */

// ➕ Add credit
userSchema.methods.addCredit = async function (amount) {
  if (amount <= 0) throw new Error("Invalid credit amount");
  this.credit += amount;
  return this.save();
};

// ➖ Withdraw credit
userSchema.methods.withdrawCredit = async function (amount) {
  if (amount <= 0) throw new Error("Invalid withdrawal amount");
  if (this.credit < amount) throw new Error("Insufficient credit");

  this.credit -= amount;
  this.totalWithdrawn += amount;
  return this.save();
};

module.exports = mongoose.model("User", userSchema);
