const express = require("express");
const { createWithdrawal, getMyWithdrawals } = require("../controllers/withdrawalController");
const protect = require("../middlewares/authMiddleware");
const router = express.Router();



/* ======================
   USER
====================== */
router.post("/request", protect, createWithdrawal);
router.get("/my", protect, getMyWithdrawals);

/* ======================
   ADMIN
====================== */
// router.get("/all", protect, adminOnly, getAllWithdrawals);
// router.put("/approve/:id", protect, adminOnly, approveWithdrawal);
// router.put("/reject/:id", protect, adminOnly, rejectWithdrawal);

module.exports = router;
