const express = require("express");
const protect = require("../middlewares/authMiddleware");
const { createDeposit, getMyDeposits, updateDepositStatus } = require("../controllers/depositController");
const router = express.Router();



/* USER */
router.post("/", protect, createDeposit);
router.get("/my", protect, getMyDeposits);

/* ADMIN */
// router.get("/", protect, admin, getAllDeposits);
router.put("/:id",  updateDepositStatus);

module.exports = router;
